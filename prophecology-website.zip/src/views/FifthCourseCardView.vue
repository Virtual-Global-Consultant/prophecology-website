<script setup lang="ts">
import DefaultProgramPageComponent from '@/components/Dashboard/Programs/DefaultProgramPageComponent.vue'
</script>
<template>
  <DefaultProgramPageComponent />
</template>
