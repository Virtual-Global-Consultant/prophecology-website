<script setup>
import DashboardDefaultPageComponent from '@/components/Pages/DashboardDefaultPageComponent.vue';
</script>
<template>
    <div class="py-36 m-auto font-Trueno">
        <DashboardDefaultPageComponent />
    </div>
</template>