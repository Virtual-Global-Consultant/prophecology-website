<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none">
    <path d="M17.625 3.75L1.5 31.5H33.75L17.625 3.75Z" stroke="#B79449" stroke-width="2.5" stroke-linejoin="round"/>
    <path d="M17.625 25.6579V26.3882M17.625 13.9737L17.6313 21.2763" stroke="#B79449" stroke-width="2.5" stroke-linecap="round"/>
  </svg>
</template>
