<template>
  <input
    name="notification"
    class="w-4 h-4 border-2 border-gold rounded-sm checked:bg-gold checked:bg-opacity-50 cursor-pointer appearance-none"
  />
</template>
