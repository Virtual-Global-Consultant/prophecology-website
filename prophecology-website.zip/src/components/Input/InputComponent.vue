<script>
// const props = defineProps('placeholder')
</script>
<template>
  <input
    class="border border-mid-gray focus:border-gold focus:outline-gold transition-all ease-in-out duration-300 h-1/6 rounded-md p-3"
    type="text"
    required
  />
</template>
