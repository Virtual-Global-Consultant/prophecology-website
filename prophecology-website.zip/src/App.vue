<script setup>
import Navbar from "@/components/Navbar/NavbarComponent.vue"
</script>

<template>
  <Navbar />
  <RouterView />
</template>

